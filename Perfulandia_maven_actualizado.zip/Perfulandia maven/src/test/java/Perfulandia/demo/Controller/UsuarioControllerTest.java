package Perfulandia.demo.Controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import Perfulandia.demo.Service.UsuarioService;
import Perfulandia.demo.Model.Usuario;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;

import static org.mockito.Mockito.when;

@WebMvcTest(UsuarioController.class)
public class UsuarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UsuarioService usuarioService;

    @Test
    public void testGetById() throws Exception {
        Usuario obj = new Usuario();
        when(usuarioService.buscarPorId(1L)).thenReturn(Optional.of(obj));

        mockMvc.perform(get("/usuarios/1"))
               .andExpect(status().isOk());
    }
}
