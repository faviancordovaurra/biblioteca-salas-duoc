package Perfulandia.demo.Service;

import Perfulandia.demo.Model.Sucursal;
import Perfulandia.demo.Repository.SucursalRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class SucursalServiceTest {

    @Mock
    private SucursalRepository sucursalRepository;

    @InjectMocks
    private SucursalService sucursalService;

    private Sucursal sucursal;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        sucursal = new Sucursal();
        sucursal.setId(1L);
        sucursal.setNombre("Sucursal Centro");
        sucursal.setCiudad("Santiago");
        sucursal.setUbicacion("Av. Principal 123");
        sucursal.setTelefono("123456789");
    }

    @Test
    void testGetAllSucursales() {
        when(sucursalRepository.findAll()).thenReturn(Arrays.asList(sucursal));
        List<Sucursal> sucursales = sucursalService.getAllSucursales();

        assertNotNull(sucursales);
        assertEquals(1, sucursales.size());
        verify(sucursalRepository, times(1)).findAll();
    }

    @Test
    void testGetSucursalByIdFound() {
        when(sucursalRepository.findById(1L)).thenReturn(Optional.of(sucursal));
        Optional<Sucursal> result = sucursalService.getSucursalById(1L);

        assertTrue(result.isPresent());
        assertEquals("Sucursal Centro", result.get().getNombre());
    }

    @Test
    void testGetSucursalByIdNotFound() {
        when(sucursalRepository.findById(99L)).thenReturn(Optional.empty());
        Optional<Sucursal> result = sucursalService.getSucursalById(99L);

        assertFalse(result.isPresent());
    }

    @Test
    void testCreateSucursal() {
        when(sucursalRepository.save(sucursal)).thenReturn(sucursal);
        Sucursal creada = sucursalService.createSucursal(sucursal);

        assertNotNull(creada);
        assertEquals("Santiago", creada.getCiudad());
    }

    @Test
    void testUpdateSucursalFound() {
        when(sucursalRepository.findById(1L)).thenReturn(Optional.of(sucursal));
        when(sucursalRepository.save(any(Sucursal.class))).thenReturn(sucursal);

        Sucursal actualizada = sucursalService.updateSucursal(1L, sucursal);
        assertNotNull(actualizada);
    }

    @Test
    void testUpdateSucursalNotFound() {
        when(sucursalRepository.findById(1L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            sucursalService.updateSucursal(1L, sucursal);
        });

        assertTrue(exception.getMessage().contains("Sucursal no encontrada"));
    }

    @Test
    void testDeleteSucursalFound() {
        when(sucursalRepository.existsById(1L)).thenReturn(true);
        doNothing().when(sucursalRepository).deleteById(1L);

        assertDoesNotThrow(() -> sucursalService.deleteSucursal(1L));
        verify(sucursalRepository, times(1)).deleteById(1L);
    }

    @Test
    void testDeleteSucursalNotFound() {
        when(sucursalRepository.existsById(1L)).thenReturn(false);

        Exception exception = assertThrows(RuntimeException.class, () -> {
            sucursalService.deleteSucursal(1L);
        });

        assertTrue(exception.getMessage().contains("Sucursal no encontrada"));
    }

    @Test
    void testDeleteAllSucursales() {
        doNothing().when(sucursalRepository).deleteAll();
        sucursalService.deleteAllSucursales();
        verify(sucursalRepository, times(1)).deleteAll();
    }
}
