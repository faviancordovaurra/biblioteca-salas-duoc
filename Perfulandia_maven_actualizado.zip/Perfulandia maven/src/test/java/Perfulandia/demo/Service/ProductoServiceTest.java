package Perfulandia.demo.Service;

import Perfulandia.demo.Model.Producto;
import Perfulandia.demo.Repository.ProductoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class ProductoServiceTest {

    @Mock
    private ProductoRepository productoRepository;

    @InjectMocks
    private ProductoService productoService;

    private Producto producto;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        producto = new Producto();
        producto.setId(1L);
        producto.setNombre("Perfume Elegante");
        producto.setMarca("Perfulandia");
        producto.setPrecio(25000.0);
        producto.setStock(10);
    }

    @Test
    void testGetAllProducts() {
        when(productoRepository.findAll()).thenReturn(Arrays.asList(producto));
        List<Producto> productos = productoService.getAllProducts();

        assertNotNull(productos);
        assertEquals(1, productos.size());
        verify(productoRepository, times(1)).findAll();
    }

    @Test
    void testGetProductoById() {
        when(productoRepository.findById(1L)).thenReturn(Optional.of(producto));
        Optional<Producto> resultado = productoService.getProductoById(1L);

        assertTrue(resultado.isPresent());
        assertEquals("Perfume Elegante", resultado.get().getNombre());
    }

    @Test
    void testCreateProducto() {
        when(productoRepository.save(producto)).thenReturn(producto);
        Producto creado = productoService.createProducto(producto);

        assertNotNull(creado);
        assertEquals("Perfulandia", creado.getMarca());
    }

    @Test
    void testUpdateProductoSuccess() {
        when(productoRepository.findById(1L)).thenReturn(Optional.of(producto));
        when(productoRepository.save(any(Producto.class))).thenReturn(producto);

        Producto actualizado = productoService.updateProducto(1L, producto);
        assertNotNull(actualizado);
    }

    @Test
    void testUpdateProductoNotFound() {
        when(productoRepository.findById(1L)).thenReturn(Optional.empty());
        Exception exception = assertThrows(RuntimeException.class, () -> {
            productoService.updateProducto(1L, producto);
        });
        assertTrue(exception.getMessage().contains("Producto no encontrado"));
    }

    @Test
    void testDeleteProductoSuccess() {
        when(productoRepository.existsById(1L)).thenReturn(true);
        doNothing().when(productoRepository).deleteById(1L);

        assertDoesNotThrow(() -> productoService.deleteProducto(1L));
        verify(productoRepository, times(1)).deleteById(1L);
    }

    @Test
    void testDeleteProductoNotFound() {
        when(productoRepository.existsById(1L)).thenReturn(false);

        Exception exception = assertThrows(RuntimeException.class, () -> {
            productoService.deleteProducto(1L);
        });
        assertTrue(exception.getMessage().contains("Producto no encontrado"));
    }
}
