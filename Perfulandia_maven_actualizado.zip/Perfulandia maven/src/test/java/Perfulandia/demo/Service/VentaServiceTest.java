package Perfulandia.demo.Service;

import Perfulandia.demo.Model.Venta;
import Perfulandia.demo.Repository.VentaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class VentaServiceTest {

    @Mock
    private VentaRepository ventaRepository;

    @InjectMocks
    private VentaService ventaService;

    private Venta venta;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        venta = new Venta();
        venta.setId(1L);
        venta.setFechaVenta(LocalDate.of(2025, 6, 1));
        venta.setTotal(29990.0);
    }

    @Test
    void testGetAllVentas() {
        when(ventaRepository.findAll()).thenReturn(Arrays.asList(venta));
        List<Venta> ventas = ventaService.getAllVentas();

        assertNotNull(ventas);
        assertEquals(1, ventas.size());
        verify(ventaRepository, times(1)).findAll();
    }

    @Test
    void testGetVentaByIdFound() {
        when(ventaRepository.findById(1L)).thenReturn(Optional.of(venta));
        Optional<Venta> result = ventaService.getVentaById(1L);

        assertTrue(result.isPresent());
        assertEquals(29990.0, result.get().getTotal());
    }

    @Test
    void testGetVentaByIdNotFound() {
        when(ventaRepository.findById(99L)).thenReturn(Optional.empty());
        Optional<Venta> result = ventaService.getVentaById(99L);

        assertFalse(result.isPresent());
    }

    @Test
    void testCreateVenta() {
        when(ventaRepository.save(venta)).thenReturn(venta);
        Venta creada = ventaService.createVenta(venta);

        assertNotNull(creada);
        assertEquals(29990.0, creada.getTotal());
    }

    @Test
    void testUpdateVentaFound() {
        when(ventaRepository.findById(1L)).thenReturn(Optional.of(venta));
        when(ventaRepository.save(any(Venta.class))).thenReturn(venta);

        Venta actualizada = ventaService.updateVenta(1L, venta);
        assertNotNull(actualizada);
        assertEquals(1L, actualizada.getId());
    }

    @Test
    void testUpdateVentaNotFound() {
        when(ventaRepository.findById(1L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            ventaService.updateVenta(1L, venta);
        });

        assertTrue(exception.getMessage().contains("Venta no encontrada"));
    }

    @Test
    void testDeleteVentaFound() {
        when(ventaRepository.existsById(1L)).thenReturn(true);
        doNothing().when(ventaRepository).deleteById(1L);

        assertDoesNotThrow(() -> ventaService.deleteVenta(1L));
        verify(ventaRepository, times(1)).deleteById(1L);
    }

    @Test
    void testDeleteVentaNotFound() {
        when(ventaRepository.existsById(1L)).thenReturn(false);

        Exception exception = assertThrows(RuntimeException.class, () -> {
            ventaService.deleteVenta(1L);
        });

        assertTrue(exception.getMessage().contains("Venta no encontrada"));
    }

    @Test
    void testDeleteAllVentas() {
        doNothing().when(ventaRepository).deleteAll();
        ventaService.deleteAllVentas();
        verify(ventaRepository, times(1)).deleteAll();
    }
}
