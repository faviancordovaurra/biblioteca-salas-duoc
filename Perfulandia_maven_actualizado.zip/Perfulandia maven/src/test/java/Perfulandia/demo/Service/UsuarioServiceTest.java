package Perfulandia.demo.Service;

import Perfulandia.demo.Model.Usuario;
import Perfulandia.demo.Repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UsuarioServiceTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @InjectMocks
    private UsuarioService usuarioService;

    private Usuario usuario;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        usuario = new Usuario();
        usuario.setId(1L);
        usuario.setNombre("Juan Pérez");
        usuario.setCorreo("juan@example.com");
        usuario.setPass("1234");
        usuario.setRol("admin");
    }

    @Test
    void testGetAllUsuarios() {
        when(usuarioRepository.findAll()).thenReturn(Arrays.asList(usuario));

        List<Usuario> usuarios = usuarioService.getAllUsuarios();

        assertNotNull(usuarios);
        assertEquals(1, usuarios.size());
        verify(usuarioRepository, times(1)).findAll();
    }

    @Test
    void testGetUsuarioByIdFound() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));

        Optional<Usuario> result = usuarioService.getUsuarioById(1L);
        assertTrue(result.isPresent());
        assertEquals("Juan Pérez", result.get().getNombre());
    }

    @Test
    void testGetUsuarioByIdNotFound() {
        when(usuarioRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Usuario> result = usuarioService.getUsuarioById(99L);
        assertFalse(result.isPresent());
    }

    @Test
    void testCreateUsuario() {
        when(usuarioRepository.save(usuario)).thenReturn(usuario);

        Usuario nuevo = usuarioService.createUsuario(usuario);
        assertNotNull(nuevo);
        assertEquals("juan@example.com", nuevo.getCorreo());
    }

    @Test
    void testUpdateUsuarioFound() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(usuario);

        Usuario actualizado = usuarioService.updateUsuario(1L, usuario);
        assertNotNull(actualizado);
        assertEquals("Juan Pérez", actualizado.getNombre());
    }

    @Test
    void testUpdateUsuarioNotFound() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            usuarioService.updateUsuario(1L, usuario);
        });

        assertTrue(exception.getMessage().contains("Usuario no encontrado"));
    }

    @Test
    void testDeleteUsuarioFound() {
        when(usuarioRepository.existsById(1L)).thenReturn(true);
        doNothing().when(usuarioRepository).deleteById(1L);

        assertDoesNotThrow(() -> usuarioService.deleteUsuario(1L));
        verify(usuarioRepository, times(1)).deleteById(1L);
    }

    @Test
    void testDeleteUsuarioNotFound() {
        when(usuarioRepository.existsById(1L)).thenReturn(false);

        Exception exception = assertThrows(RuntimeException.class, () -> {
            usuarioService.deleteUsuario(1L);
        });

        assertTrue(exception.getMessage().contains("Usuario no encontrado"));
    }

    @Test
    void testDeleteAllUsuarios() {
        doNothing().when(usuarioRepository).deleteAll();
        usuarioService.deleteAllUsuarios();
        verify(usuarioRepository, times(1)).deleteAll();
    }
}
