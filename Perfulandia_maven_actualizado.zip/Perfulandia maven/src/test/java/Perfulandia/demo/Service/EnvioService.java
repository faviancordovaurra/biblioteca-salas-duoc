package Perfulandia.demo.Service;

import Perfulandia.demo.Model.Envio;
import Perfulandia.demo.Repository.EnvioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class EnvioServiceTest {

    @Mock
    private EnvioRepository envioRepository;

    @InjectMocks
    private EnvioService envioService;

    private Envio envio;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        envio = new Envio();
        envio.setId(1L);
        envio.setDireccion("Calle Falsa 123");
        envio.setEstado("En camino");
        envio.setFechaEnvio(LocalDate.now());
    }

    @Test
    void testGetAllEnvios() {
        when(envioRepository.findAll()).thenReturn(Arrays.asList(envio));
        List<Envio> envios = envioService.getAllEnvios();

        assertNotNull(envios);
        assertEquals(1, envios.size());
        verify(envioRepository, times(1)).findAll();
    }

    @Test
    void testGetEnvioByIdFound() {
        when(envioRepository.findById(1L)).thenReturn(Optional.of(envio));
        Optional<Envio> result = envioService.getEnvioById(1L);

        assertTrue(result.isPresent());
        assertEquals("Calle Falsa 123", result.get().getDireccion());
    }

    @Test
    void testGetEnvioByIdNotFound() {
        when(envioRepository.findById(99L)).thenReturn(Optional.empty());
        Optional<Envio> result = envioService.getEnvioById(99L);

        assertFalse(result.isPresent());
    }

    @Test
    void testCreateEnvio() {
        when(envioRepository.save(envio)).thenReturn(envio);
        Envio creado = envioService.createEnvio(envio);

        assertNotNull(creado);
        assertEquals("En camino", creado.getEstado());
    }

    @Test
    void testUpdateEnvioFound() {
        when(envioRepository.findById(1L)).thenReturn(Optional.of(envio));
        when(envioRepository.save(any(Envio.class))).thenReturn(envio);

        Envio actualizado = envioService.updateEnvio(1L, envio);
        assertNotNull(actualizado);
    }

    @Test
    void testUpdateEnvioNotFound() {
        when(envioRepository.findById(1L)).thenReturn(Optional.empty());

        Exception exception = assertThrows(RuntimeException.class, () -> {
            envioService.updateEnvio(1L, envio);
        });
        assertTrue(exception.getMessage().contains("Envio no encontrado"));
    }

    @Test
    void testDeleteEnvioFound() {
        when(envioRepository.existsById(1L)).thenReturn(true);
        doNothing().when(envioRepository).deleteById(1L);

        assertDoesNotThrow(() -> envioService.deleteEnvio(1L));
        verify(envioRepository, times(1)).deleteById(1L);
    }

    @Test
    void testDeleteEnvioNotFound() {
        when(envioRepository.existsById(1L)).thenReturn(false);

        Exception exception = assertThrows(RuntimeException.class, () -> {
            envioService.deleteEnvio(1L);
        });
        assertTrue(exception.getMessage().contains("Envio no encontrado"));
    }

    @Test
    void testDeleteAllEnvios() {
        doNothing().when(envioRepository).deleteAll();
        envioService.deleteAllEnvios();
        verify(envioRepository, times(1)).deleteAll();
    }
}
