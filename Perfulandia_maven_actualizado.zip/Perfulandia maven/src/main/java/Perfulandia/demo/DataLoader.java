package Perfulandia.demo;


import net.datafaker.Faker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import Perfulandia.demo.Model.Envio;
import Perfulandia.demo.Model.Producto;
import Perfulandia.demo.Model.Sucursal;
import Perfulandia.demo.Model.Usuario;
import Perfulandia.demo.Model.Venta;
import Perfulandia.demo.Repository.EnvioRepository;
import Perfulandia.demo.Repository.ProductoRepository;
import Perfulandia.demo.Repository.SucursalRepository;
import Perfulandia.demo.Repository.UsuarioRepository;
import Perfulandia.demo.Repository.VentaRepository;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.Random;
@Profile("dev")
@Component
public class DataLoader implements CommandLineRunner {
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private EnvioRepository envioRepository;
    @Autowired
    private ProductoRepository productoRepository;
    @Autowired
    private SucursalRepository sucursalRepository;
    @Autowired
    private VentaRepository ventaRepository;
    @Override
    public void run(String... args) throws Exception {
        Faker faker = new Faker();
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            Usuario usuario = new Usuario();
            usuario.setNombre(faker.name().fullName());
            usuario.setCorreo(faker.internet().emailAddress());
            usuario.setPass(faker.internet().password());
            usuario.setRol(faker.options().option("admin","supervizor","empleado"));
            usuarioRepository.save(usuario);
            }
     // Crear productos
        for (int i = 0; i < 10; i++) {
            Producto producto = new Producto();
            producto.setNombre(faker.commerce().productName());
            producto.setMarca(faker.company().name());
            producto.setPrecio(Double.parseDouble(faker.commerce().price()));
            producto.setStock(random.nextInt(100) + 1);
            productoRepository.save(producto);
        }

        // Crear sucursales
        for (int i = 0; i < 5; i++) {
            Sucursal sucursal = new Sucursal();
            sucursal.setNombre(faker.company().name());
            sucursal.setUbicacion(faker.address().streetAddress());
            sucursal.setCiudad(faker.address().city());
            sucursal.setTelefono(faker.phoneNumber().cellPhone());
            sucursalRepository.save(sucursal);
        }

        List<Usuario> usuarios = usuarioRepository.findAll();
        List<Producto> productos = productoRepository.findAll();
        List<Sucursal> sucursales = sucursalRepository.findAll();

        // Crear ventas
        for (int i = 0; i < 10; i++) {
            Venta venta = new Venta();
            Date FechaAleatoria = faker.date().past(730, java.util.concurrent.TimeUnit.DAYS);
            LocalDate Fecha = FechaAleatoria.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            venta.setTotal(Double.parseDouble(faker.commerce().price()));
            ventaRepository.save(venta);
        }

        List<Venta> ventas = ventaRepository.findAll();

        // Crear envíos
        for (Venta venta : ventas) {
            Envio envio = new Envio();
            envio.setDireccion(faker.address().fullAddress());
            envio.setEstado(faker.options().option("Pendiente", "En camino", "Entregado"));
            envio.setFechaEnvio(LocalDate.now().plusDays(random.nextInt(5)));
            envioRepository.save(envio);
        }
    }
}