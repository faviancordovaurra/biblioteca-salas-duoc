package Perfulandia.demo.Controller;

import Perfulandia.demo.Model.Venta;
import Perfulandia.demo.Service.VentaService;
import Perfulandia.demo.Assembler.VentaModelAssembler;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/ventas")
public class VentaControllerV2 {

    private final VentaService ventaService;
    private final VentaModelAssembler assembler;

    public VentaControllerV2(VentaService ventaService, VentaModelAssembler assembler) {
        this.ventaService = ventaService;
        this.assembler = assembler;
    }

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<Venta>>> getAllVentas() {
        List<Venta> ventas = ventaService.getAllVentas();
        List<EntityModel<Venta>> ventaModels = ventas.stream()
                .map(assembler::toModel)
                .toList();

        return ResponseEntity.ok(
                CollectionModel.of(ventaModels,
                        linkTo(methodOn(VentaControllerV2.class).getAllVentas()).withSelfRel()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<Venta>> getVentaById(@PathVariable Long id) {
        Optional<Venta> venta = ventaService.getVentaById(id);

        return venta.map(value ->
                ResponseEntity.ok(assembler.toModel(value)))
                .orElse(ResponseEntity.notFound().build());
    }
}
