package Perfulandia.demo.Controller;

import Perfulandia.demo.Model.Sucursal;
import Perfulandia.demo.Service.SucursalService;
import Perfulandia.demo.Assembler.SucursalModelAssembler;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/sucursales")
public class SucursalControllerV2 {

    private final SucursalService sucursalService;
    private final SucursalModelAssembler assembler;

    public SucursalControllerV2(SucursalService sucursalService, SucursalModelAssembler assembler) {
        this.sucursalService = sucursalService;
        this.assembler = assembler;
    }

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<Sucursal>>> getAllSucursales() {
        List<Sucursal> sucursales = sucursalService.getAllSucursales();
        List<EntityModel<Sucursal>> sucursalModels = sucursales.stream()
                .map(assembler::toModel)
                .toList();

        return ResponseEntity.ok(
                CollectionModel.of(sucursalModels,
                        linkTo(methodOn(SucursalControllerV2.class).getAllSucursales()).withSelfRel()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<Sucursal>> getSucursalById(@PathVariable Long id) {
        Optional<Sucursal> sucursal = sucursalService.getSucursalById(id);

        return sucursal.map(value -> ResponseEntity.ok(assembler.toModel(value)))
                .orElse(ResponseEntity.notFound().build());
    }
}
