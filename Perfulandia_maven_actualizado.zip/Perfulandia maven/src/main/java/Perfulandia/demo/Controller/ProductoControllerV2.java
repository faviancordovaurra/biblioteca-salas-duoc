package Perfulandia.demo.Controller;

import Perfulandia.demo.Model.Producto;
import Perfulandia.demo.Service.ProductoService;
import Perfulandia.demo.Assembler.ProductoModelAssembler;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v2/productos")
public class ProductoControllerV2 {

    private final ProductoService productoService;
    private final ProductoModelAssembler assembler;

    public ProductoControllerV2(ProductoService productoService, ProductoModelAssembler assembler) {
        this.productoService = productoService;
        this.assembler = assembler;
    }

    @GetMapping
    public ResponseEntity<CollectionModel<EntityModel<Producto>>> getAllProductos() {
        List<Producto> productos = productoService.getAllProducts();
        List<EntityModel<Producto>> productoModels = productos.stream()
                .map(assembler::toModel)
                .toList();

        return ResponseEntity.ok(
                CollectionModel.of(productoModels,
                        linkTo(methodOn(ProductoControllerV2.class).getAllProductos()).withSelfRel()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<EntityModel<Producto>> getProductoById(@PathVariable Long id) {
        Optional<Producto> producto = productoService.getProductoById(id);

        return producto.map(value -> ResponseEntity.ok(assembler.toModel(value)))
                .orElse(ResponseEntity.notFound().build());
    }
}
