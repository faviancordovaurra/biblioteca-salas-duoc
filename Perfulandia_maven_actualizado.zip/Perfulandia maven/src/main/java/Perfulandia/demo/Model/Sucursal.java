package Perfulandia.demo.Model;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Sucursal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String ubicacion;
    private String ciudad;
    private String telefono;

    public void setId(long l) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setNombre(String sucursal_Test) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
