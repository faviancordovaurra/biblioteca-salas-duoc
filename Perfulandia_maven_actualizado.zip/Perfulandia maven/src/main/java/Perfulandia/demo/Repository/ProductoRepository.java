package Perfulandia.demo.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Perfulandia.demo.Model.Producto;

@Repository
public interface ProductoRepository extends JpaRepository<Producto,Long> {

}
