package Perfulandia.demo.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Perfulandia.demo.Model.Envio;

@Repository
public interface EnvioRepository extends JpaRepository<Envio,Long> {

}
