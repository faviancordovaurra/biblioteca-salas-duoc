package biblioteca.salas.duoc.biblioteca.salas.duoc.repository;


import biblioteca.salas.duoc.biblioteca.salas.duoc.model.Estudiante;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstudianteRepository extends JpaRepository<Estudiante, Integer> {
}
